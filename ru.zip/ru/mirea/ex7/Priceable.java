package ru.mirea.ex7;

public interface Priceable {
    int getPrice();
}
