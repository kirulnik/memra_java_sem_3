package ru.mirea.ex7;

public class BMw implements Priceable{
    protected String model;
    protected int number;
    protected int price;
    @Override
    public int getPrice(){
        return price;
    }
    public String getModel(){
        return model;
    }
    public int getNumber(){
        return number;
    }
    public void setPrice(int price){
        this.price=price;
    }
    public BMw(String model, int price, int number){
        this.model=model;
        this.price=price;
        this.number=number;
    }
    @Override
    public String toString(){
        return "BMw: " + "\n" + "What!? " + number + " " + model +
                " for only " + price + " pounds, yes, sir!";
    }
    public static void main(String[] args) {
        BMw bmw = new BMw("m5",2, 300);
        System.out.println(bmw);
        bmw.setPrice(3);
        System.out.println("New price: " + bmw.getPrice() + " pounds");
    }
}
