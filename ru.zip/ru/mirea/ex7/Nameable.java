package ru.mirea.ex7;

public interface Nameable {
    String getName();
}
