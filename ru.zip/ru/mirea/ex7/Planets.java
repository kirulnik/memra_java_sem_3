package ru.mirea.ex7;

public class Planets implements Nameable{
    protected String name;
    public String getName(){
        return name;
    }
    public Planets(String name){
        this.name=name;
    }
    public static void main(String[] args) {
        Planets planet1 = new Planets("Земля");
        System.out.println(planet1.getName());
    }
}
