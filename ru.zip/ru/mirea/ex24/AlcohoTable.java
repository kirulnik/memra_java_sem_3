package ru.mirea.ex24;

interface AlcohoTable {
    public boolean isAlcoholicDrink();
    public double getAlcoholVol();
}
