package ru.mirea.ex22;

public class MagicChair implements Chair{
    public void doMagic() {
        System.out.println("Стул кастует фаербол, ПРИГНИСЬ!");
    }
}

