package ru.mirea.ex22;

public class Client {
    public Chair chair;
    public void sit(){
        System.out.println("Клиент сел на стул, с ним всё хорошо!");
    }
    public void setChair(Chair chair) {
        this.chair = chair;
    }
}
