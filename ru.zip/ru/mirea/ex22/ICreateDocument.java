package ru.mirea.ex22;

import java.io.FileNotFoundException;
public interface ICreateDocument<T> {
    IDocument<T> CreateNew();
    IDocument<T> CreateOpen(String path) throws FileNotFoundException;
}

