package ru.mirea.ex22;

import java.util.Scanner;
public class TestChair {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Client client = new Client();
        AbstractChairFactory factory = new ChairFactory();
        System.out.println("Выберите номер стула"+"\n" +
                "1 - Викторианский; "+ "\n" +
                "2 - Волшебный;"+"\n"+
                "3 - Многофункциональный: ");
        int chair_num = sc.nextInt();
        if (chair_num == 1) {
            VictorianChair victorian = factory.createVictorianChair();
            client.setChair(victorian);
            System.out.println(victorian.getAge() + " лет");
        }
        if (chair_num == 2) {
            MagicChair magic = factory.createMagicChair();
            client.setChair(magic);
            magic.doMagic();
        }
        if (chair_num == 3) {
            FunctionalChair chair = factory.createFunctionalChair();
            client.setChair(chair);
            System.out.println("Сумма = " + chair.sum(23, 77));
        }
        if (chair_num == 1 || chair_num == 2 || chair_num == 3) client.sit();
    }
}

