package ru.mirea.ex22;

public class TestComplex {
    public static void main(String[] args) {
        ComplexAbstractFactory compl_factory = new ConcreteFactory();
        System.out.println(compl_factory.CreateComplex(20, 43));
        System.out.println(compl_factory.createComplex());
    }
}
