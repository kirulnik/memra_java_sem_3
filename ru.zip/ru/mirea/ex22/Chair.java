package ru.mirea.ex22;

public interface Chair {
}
