package ru.mirea.ex22;

public interface ComplexAbstractFactory {
    Complex createComplex();
    Complex CreateComplex(int real, int image);
}

