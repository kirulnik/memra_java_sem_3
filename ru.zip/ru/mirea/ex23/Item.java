package ru.mirea.ex23;

public interface Item {
    double getCost();
    String getName();
    String getDescription();
}

