package ru.mirea.ex18;

public class Calculator {
    public static <T extends Number> double sum(T num1, T num2) {
        return num1.doubleValue() + num2.doubleValue();
    }
    public static <T extends Number> double multiply(T num1, T num2) {
        return num1.doubleValue() * num2.doubleValue();
    }
    public static <T extends Number> double divide(T num1, T num2) {
        return num1.doubleValue() / num2.doubleValue();
    }
    public static <T extends Number> double subtraction(T num1, T num2) {
        return num1.doubleValue() - num2.doubleValue();
    }
    public static void main(String[] args) {
        System.out.println("Sum: " + sum(5, 10));
        System.out.println("Multiply: " + multiply(5, 10));
        System.out.println("Divide: " + divide(5, 10));
        System.out.println("Subtraction: " + subtraction(5, 10));
    }
}
