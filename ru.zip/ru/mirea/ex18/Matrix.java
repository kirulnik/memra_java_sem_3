package ru.mirea.ex18;

public class Matrix<T extends Integer> {
    private T [][] matrix1;
    private T [][] matrix2;
    public Matrix(T [][] matrix1, T [][] matrix2){
        this.matrix1 = matrix1;
        this.matrix2 = matrix2;
    }
    public void sum(){
        System.out.println("Сумма матриц:");
        for(int i = 0; i < matrix1.length; i++){
            for(int j = 0; j < matrix1[0].length; j++){
                System.out.print(matrix1[i][j].intValue() + matrix2[i][j].intValue()+" ");
            }
            System.out.println();
        }
    }
    public void multiply(){
        int [][] multiplyMatrix = new int[matrix1[0].length][matrix1.length];
        System.out.println("Произведение матриц:");
        for(int i = 0; i < matrix1.length; i++){
            for(int j = 0; j < matrix1[0].length; j++){
                for(int k = 0; k < matrix1.length; k++){
                    multiplyMatrix[i][j] += matrix1[i][k].intValue() * matrix2[k][j].intValue();
                }
            }
        }
        for (int i = 0; i < multiplyMatrix.length; i++){
            for (int j = 0; j < multiplyMatrix[0].length; j++){
                System.out.print(multiplyMatrix[i][j]+ " ");
            }
            System.out.println();
        }
    }
    public void transp(){
        Number [][] tMatrix1 = new Number[matrix1[0].length][matrix1.length];
        System.out.println("Транспонированная первая матрица:");
        for(int i = 0; i < matrix1.length; i++){
            for(int j = 0; j < matrix1[0].length; j++){
                tMatrix1[j][i] = matrix1[i][j];
            }
        }
        for(int i = 0; i < tMatrix1.length; i++){
            for(int j = 0; j < tMatrix1[0].length; j++){
                System.out.print(tMatrix1[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("Транспонированная вторая матрица:");
        Number[][] tMatrix2 = new Number[matrix2[0].length][matrix2.length];
        for (int i = 0; i < matrix2.length; i++){
            for(int j = 0; j < matrix2[0].length; j++){
                tMatrix2[j][i] = matrix2[i][j];
            }
        }
        for(int i = 0; i < tMatrix2.length; i++){
            for (int j = 0; j < tMatrix2[0].length; j++){
                System.out.print(tMatrix2[i][j]+" ");
            }
            System.out.println();
        }
    }
    public void print(){
        System.out.println("Вывод первой матрицы:");
        for(int i = 0; i < matrix1.length; i++){
            for(int j = 0; j < matrix1[0].length; j++){
                System.out.print(matrix1[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("Вывод второй матрицы: ");
        for(int i = 0; i < matrix2.length; i++){
            for(int j = 0; j < matrix2[0].length; j++){
                System.out.print(matrix2[i][j]+" ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Integer[][] m1 = new Integer[][] {{1, 2, 3}, {4, 5, 6}, {7,8,9}};
        Integer[][] m2 = new Integer[][] {{4, 2, 0}, {2, 2, 8}, {1, 1, 1}};
        Matrix<Integer> matrix = new Matrix<>(m1, m2);
        matrix.print();
        matrix.sum();
        matrix.transp();
        matrix.multiply();
    }
}
