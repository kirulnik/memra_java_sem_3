package ru.mirea.ex18;
class Animal{
}
public class TVK <T extends String, V extends Animal, K extends Integer>{
    private T v1;
    private V v2;
    private K v3;
    public TVK(T v1, V v2, K v3){
        this.v1=v1;
        this.v2=v2;
        this.v3=v3;
    }
    public T getV1(){
        return v1;
    }
    public V getV2(){
        return v2;
    }
    public K getV3(){
        return v3;
    }
    @Override
    public String toString() {
        return v1 + "=" + v1.getClass() + "\n" +
                v2 + "=" + v2.getClass() + "\n" +
                v3 + "=" + v3.getClass();

    }
    public static void main(String[] args) {
        TVK<String, Animal, Integer> test_obj = new TVK<>("test", new Animal(), 10);
        System.out.println(test_obj.toString());
    }
}
