package ru.mirea.ex18;

public class MinMax<T extends Comparable<T>> {
    private T[] array;
    public MinMax(T[] array) {
        this.array = array;
    }
    public T findMin() {
        T min = array[0];
        for (T element : array) {
            if (element.compareTo(min) < 0) {
                min = element;
            }
        }
        return min;
    }
    public T findMax() {
        T max = array[0];
        for (T element : array) {
            if (element.compareTo(max) > 0) {
                max = element;
            }
        }
        return max;
    }
    public static void main(String[] args) {
        MinMax<Integer> minMax = new MinMax<>(new Integer[]{10, 5, 15, 20, 5});
        System.out.println("Min: " + minMax.findMin());
        System.out.println("Max: " + minMax.findMax());
    }
}
