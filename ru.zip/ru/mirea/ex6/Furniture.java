package ru.mirea.ex6;

abstract public class Furniture {
    protected String material;
    protected String item;
    public String getMaterial() {
        return material;
    }
    public String getItem() {
        return item;
    }
    public void setMaterial(String material) {
        this.material = material;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public Furniture(String material, String item) {
        this.material = material;
        this.item = item;
    }
    public Furniture() {
        this.material = "undefined";
        this.item = "undefined";
    }
    @Override
    public String toString() {
        return "--Мебель--" + "\n" +
                "материал: " + material + "\n" +
                "предмет" + item;
    }
}

