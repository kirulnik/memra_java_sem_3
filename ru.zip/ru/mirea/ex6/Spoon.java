package ru.mirea.ex6;

public class Spoon extends Dish{
    protected String type;
    public Spoon(String material, String item, String type){
        super(material, item);
        this.type=type;
    }
    public Spoon(String type) {
        this.type=type;
    }
    public String getType(){
        return type;
    }
    @Override
    public String toString(){
        return "--Ложка--" + "\n" +
                "Тип: " + type + "\n" +
                "материал: " + material + "\n" +
                "предмет: " + item;
    }
}
