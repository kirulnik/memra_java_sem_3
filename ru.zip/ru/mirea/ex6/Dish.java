package ru.mirea.ex6;

abstract public class Dish {
    protected String material;
    protected String item;

    public Dish(String material, String item) {
        this.material = material;
        this.item = item;
    }

    public Dish() {
        this.material = "undefined";
        this.item = "undefined";
    }

    @Override
    public String toString() {
        return "--Посуда-- " +
                "материал: " + material + "\n" +
                "элемент посуды: " + item + "\n";
    }

    public String getItem() {
        return item;
    }

    public String getMaterial() {
        return material;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}


