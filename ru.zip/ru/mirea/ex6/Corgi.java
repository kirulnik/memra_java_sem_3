package ru.mirea.ex6;

public class Corgi extends Dog{
    protected String homeland;
    public String getHomeland() {
        return homeland;
    }
    public void setHomeland(String homeland) {
        this.homeland = homeland;
    }
    public Corgi(String homeland) {
        this.homeland = homeland;
    }
    public Corgi(String name, int age, String homeland) {
        super(name, age);
        this.homeland = homeland;
    }
    @Override
    public String toString() {
        return "--Corgi--" +
                "Родина: " + homeland + "\n" +
                "Имя: " + name + "\n" +
                "Возраст: " + age;
    }
}
