package ru.mirea.ex6;

import java.util.ArrayList;

public class FurnitureShop {
    protected ArrayList<Furniture> positions = new ArrayList<Furniture>();
    protected String shop_name;
    public FurnitureShop(String shop_name) {
        this.shop_name = shop_name;
    }
    public void sold(Furniture pos) {
        this.positions.remove(pos);
        System.out.println(pos + " продан(а)");
    }
    public void add(Furniture pos) {
        this.positions.add(pos);
        System.out.println(pos + " добавлен(а) на склад");
    }
    @Override
    public String toString() {
        if (!this.positions.isEmpty())
            return "Позиции в магазине мебели \"" + shop_name + "\": " + this.positions;
        else
            return "В магазине нет товаров";
    }
}

