package ru.mirea.ex6;

public class TestFurniture {
    public static void main(String[] args) {
        Table table1 = new Table("Дерево", "Стол №1", "Кухонный");
        Table table2 = new Table("ДСП", "Стол №2", "Детский");
        System.out.println(table1);
        System.out.println(table2);
        table1.setMaterial("Металл");
        System.out.println(table1);
        Chair chair = new Chair(26);
        Chair chair2 = new Chair("Дерево", "Стул", 26);
        System.out.println(chair);
        System.out.println(chair2);
        System.out.println("|-----------------------------------|");
        FurnitureShop shop = new FurnitureShop("Дом Hi-tech");
        System.out.println(shop);
        shop.add(table1);
        shop.add(chair2);
        System.out.println(shop);
        shop.sold(chair2);
        System.out.println(shop);
    }
}
