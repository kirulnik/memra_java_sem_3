package ru.mirea.ex6;

public class Chair extends Furniture{
    protected int seating_place_length;
    public int getSeating_place_length() {
        return seating_place_length;
    }
    public void setSeating_place_length(int seating_place_length) {
        this.seating_place_length = seating_place_length;
    }
    public Chair(String material, String item, int seating_place_length) {
        super(material, item);
        this.seating_place_length = seating_place_length;
    }
    public Chair(int seating_place_length) {
        this.seating_place_length = seating_place_length;
    }
    @Override
    public String toString() {
        return "--Стул--" + "\n" +
                "размер: " + seating_place_length + "\n" +
                "материал: " + material + "\n" +
                "предмет: " + item;
    }
}

