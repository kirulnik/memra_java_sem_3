package ru.mirea.ex6;

public class Plate extends Dish{
    protected int diameter;
    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }
    public int getDiameter() {
        return diameter;
    }
    public Plate(String material, String item, int diameter) {
        super(material, item);
        this.diameter = diameter;
    }
    @Override
    public String toString() {
        return "--Тарелка-- " + "\n" +
                "диаметр: " + diameter + "\n" +
                "материал: " + material + "\n" +
                "предмет: " + item;
    }
}

