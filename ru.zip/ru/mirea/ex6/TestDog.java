package ru.mirea.ex6;

public class TestDog {
    public static void main(String[] args) {
        Corgi john = new Corgi("John",3,"Wales");
        Corgi seny = new Corgi("Russia");
        System.out.println(john);
        System.out.println(seny);
    }
}

