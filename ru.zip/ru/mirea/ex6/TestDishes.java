package ru.mirea.ex6;

public class TestDishes {
    public static void main(String[] args) {
        Spoon spoon = new Spoon("Серебро","Ложка", "Чайная");
        Spoon spoon2 = new Spoon("Чайная");
        System.out.println(spoon);
        System.out.println(spoon2);
        Plate plate = new Plate("Фарфор","Тарелка", 100);
        System.out.println(plate);
    }
}


