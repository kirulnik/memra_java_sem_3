package ru.mirea.ex6;

public class Table extends Furniture {
    protected String type;
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Table(String material, String item, String type) {
        super(material, item);
        this.type = type;
    }
    public Table(String type) {
        this.type = type;
    }
    @Override
    public String toString() {
        return "--Стол--" + "\n" +
                "тип: " + type + "\n" +
                "материал: " + material + "\n" +
                "предмет: " + item;
    }
}

