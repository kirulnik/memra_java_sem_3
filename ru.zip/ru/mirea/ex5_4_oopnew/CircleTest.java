package ru.mirea.ex5_4_oopnew;

public class CircleTest {
    public static void main(String[] args) {
        Circle circle = new Circle(15.1, "Red");
        System.out.println("Свойства до изменения:");
        System.out.println(circle.getRadius());
        System.out.println(circle.getBorder_color());
        circle.setRadius(35.7);
        circle.setBorder_color("Blue");
        System.out.println("Свойства после изменения:");
        System.out.println(circle.getRadius());
        System.out.println(circle.getBorder_color());
    }
}
