package ru.mirea.ex5_4_oopnew;

public class Human { //Человек
    protected String name;
    protected int years;

    public Human(String name, int years) {
        this.name = name;
        this.years = years;
    }

    public Human() {
        this.name = "Undefined";
        this.years = 0;
    }

    @Override
    public String toString() {
        return "Сущность Человек {" +
                "Имя = '" + name + '\'' +
                ", Возраст = " + years +
                '}';
    }

    public class Head { //Голова
        protected String hair_color;
        protected String eyes_color;

        public String getEyes_color() {
            return eyes_color;
        }

        public String getHair_color() {
            return hair_color;
        }

        public void setHair_color(String hair_color) {
            this.hair_color = hair_color;
        }

        public Head(String hair_color, String eyes_color) {
            this.hair_color = hair_color;
            this.eyes_color = eyes_color;
        }

        @Override
        public String toString() {
            return " {" +
                    "Цвет волос = '" + hair_color + '\'' +
                    ", Цвет глаз = '" + eyes_color + '\'' +
                    '}';
        }
    }

    public  class Leg { //Нога
        public String move_forward() {
            return "Нога перемещена вперед!";
        }
        public String move_back() {
            return "Нога перемещена назад!";
        }
    }
    public class Hand { //Рука
        public String move_up() {
            return "Рука поднята!";
        }
        public String move_down() {
            return "Рука опущена!";
        }
    }

}

