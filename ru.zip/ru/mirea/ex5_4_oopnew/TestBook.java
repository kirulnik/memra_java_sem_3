package ru.mirea.ex5_4_oopnew;

public class TestBook {
    public static void main(String[] args) {
        Book book = new Book("Г.Шилдт", "Java. Полное руководство", 2018);
        System.out.println(book);
        book.setYear(book.getYear()-4);
        book.setAuthor("Герберт Шилдт");
        book.setItem("Java");
        System.out.println(book);
    }
}
