package ru.mirea.ex5_4_oopnew;

public class Circle {
    protected double radius;
    protected String border_color;

    public Circle(double radius, String border_color) {
        this.radius = radius;
        this.border_color = border_color;
    }

    public Circle() {
        this.radius = 0;
        this.border_color = "Undefined";
    }

    public double getRadius() {
        return radius;
    }

    public String getBorder_color() {
        return border_color;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setBorder_color(String border_color) {
        this.border_color = border_color;
    }
}

