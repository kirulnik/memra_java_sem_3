package ru.mirea.ex5_4_oopnew;

public class Book {
        protected String author;
        protected String item;
        protected int year;


        public String getAuthor() {
            return author;
        }

        public String getItem() {
            return item;
        }

        public int getYear() {
            return year;
        }

        public void setItem(String item) {
            this.item = item;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public void setYear(int year) {
            this.year = year;
        }

        @Override
        public String toString() {
            return "Book {" +
                    "author='" + author + '\'' +
                    ", item='" + item + '\'' +
                    ", year=" + year +
                    '}';
        }

        public Book(String author, String item, int year) {
            this.author = author;
            this.item = item;
            this.year = year;
        }
        public Book() {
            this.author = "undefind";
            this.item = "undefind";
            this.year = 0;
        }
}

