package ru.mirea.ex5_4_oopnew;

public class TestHuman {
    public static void main(String[] args) {
        Human human = new Human("Сусси", 69);
        Human.Hand left_hand = human.new Hand();
        Human.Hand right_hand = human.new Hand();
        Human.Leg left_leg = human.new Leg();
        Human.Leg right_leg = human.new Leg();
        Human.Head head = human.new Head("Шатен", "Зелёный");

        System.out.println(human);
        System.out.println("Левая рука: " + left_hand.move_down());
        System.out.println("Правая рука: " + right_hand.move_down());
        System.out.println("Левая нога: " + left_leg.move_forward());
        System.out.println("Правая нога: " + right_leg.move_back());
        System.out.println("Голова: " + head);
        head.setHair_color("Золотой");
        System.out.println("Голова: " + head);
    }
}
