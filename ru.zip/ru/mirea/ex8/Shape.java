package ru.mirea.ex8;

import javax.swing.*;
abstract public class Shape extends JPanel{
    protected int[] bg_color = new int[3];
    protected int pos;
    public int[] get_bg_color(){
        return bg_color;
    }
    public Shape(){
        this.bg_color[0] = (int) (Math.random() * 255);
        this.bg_color[1] = (int) (Math.random() * 255);
        this.bg_color[2] = (int) (Math.random() * 255);
    }
    public void setPos(int pos){
        this.pos=pos;
    }
    public int getPos(){
        return pos;
    }
}
