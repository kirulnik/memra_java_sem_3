package ru.mirea.ex8;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
public class Picture extends JFrame {
    Picture(String args) throws IOException {
        super("Мы");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 700);
        setLayout(new FlowLayout());
        JLabel lbl=new JLabel();
        lbl.setIcon( new ImageIcon(ImageIO.read( new File(args) ) ) );
        add(lbl);
        setResizable(false);
        setVisible(true);
    }
    public static void main(String[] args) throws IOException {
        Picture view = new Picture(args[0]);
    }
}

