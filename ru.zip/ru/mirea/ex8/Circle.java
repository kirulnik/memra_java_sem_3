package ru.mirea.ex8;

import java.awt.*;
public class Circle extends Shape{
    Circle(int pos) {
        this.pos=pos;
    }
    public void paint(Graphics g){
        g.setColor(new Color (get_bg_color()[0],get_bg_color()[1],get_bg_color()[2]));
        g.fillOval(getWidth() / 2, getHeight() /2, 30, 30);
    }
}
