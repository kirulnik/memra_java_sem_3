package ru.mirea.ex8;

import javax.swing.*;
import java.awt.*;
public class TestShape extends JFrame {
    JPanel[] pnl = new JPanel[20];
    public TestShape(int[] position) {
        super("Фигуры");
        JPanel grid = new JPanel();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4,5));
        for(int i = 0 ; i < pnl.length ; i++) {
            pnl[i] = new JPanel();
            add(pnl[i]);
            pnl[i].setLayout(new BorderLayout());
            switch (position[i]) {
                case 0:
                    pnl[i].add(new Circle(position[i]),BorderLayout.CENTER);
                    break;
                case 1:
                    pnl[i].add(new Rectangle(position[i]),BorderLayout.CENTER);
                    break;
                case 2:
                    pnl[i].add(new Line(position[i]),BorderLayout.CENTER);
                    break;
                default:
                    break;
            }
        }
        setSize(700,400);
        setResizable(false);
        setVisible(true);
    }
    public static void main(String[] args) {
        TestShape w = new TestShape(new int[]{0, 1, 1, 1, 2, 0, 1, 1, 2, 1, 2, 1, 1, 2, 0, 0, 1, 2, 2, 1});
    }
}

