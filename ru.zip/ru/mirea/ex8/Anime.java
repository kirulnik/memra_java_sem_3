package ru.mirea.ex8;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
public class Anime extends JFrame {
    Anime() throws IOException, InterruptedException {
        super("Анимация");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        JLabel main = new JLabel();
        add(main);
        setSize(300,695);
        setResizable(false);
        setVisible(true);
        while (true) {
            main.setIcon(new ImageIcon(ImageIO.read(new File("D:/картинки дл/1.jpg"))));
            TimeUnit.MILLISECONDS.sleep(100);
            main.setIcon(new ImageIcon(ImageIO.read(new File("D:/картинки дл/2.jpg"))));
            TimeUnit.MILLISECONDS.sleep(100);
            main.setIcon(new ImageIcon(ImageIO.read(new File("D:/картинки дл/3.jpg"))));
            TimeUnit.MILLISECONDS.sleep(100);
            main.setIcon(new ImageIcon(ImageIO.read(new File("D:/картинки дл/4.jpg"))));
            TimeUnit.MILLISECONDS.sleep(100);
            main.setIcon(new ImageIcon(ImageIO.read(new File("D:/картинки дл/5.jpg"))));
            TimeUnit.MILLISECONDS.sleep(100);
        }
    }
    public static void main(String[] args) throws IOException, InterruptedException {
        Anime view = new Anime();
    }
}

