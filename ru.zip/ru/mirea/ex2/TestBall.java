package ru.mirea.ex2;

public class TestBall {
    public static void main(String[] args) {
        Ball b1 = new Ball(0.0, 0.0);
        System.out.println(b1);
        b1.move(23, 16);
        System.out.println(b1);
        b1.move(5, 6);
        System.out.println(b1);
    }

}
