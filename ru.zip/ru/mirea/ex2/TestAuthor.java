package ru.mirea.ex2;

public class TestAuthor {
    public static void main(String[] args) {
        Author a1 = new Author("Тардасов Кирилл", "tardasov.k.e@edu.mirea.ru", 'M');
        System.out.println(a1.toString());
    }
}
