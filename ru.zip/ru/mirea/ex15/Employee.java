package ru.mirea.ex15;

public class Employee {
    private double salary;
    private String post;
    public String getPost(){
        return post;
    }
    public void setPost(String post) {
        this.post = post;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
}
