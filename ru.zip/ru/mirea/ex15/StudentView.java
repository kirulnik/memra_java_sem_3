package ru.mirea.ex15;

public class StudentView {
    public void printStudentDetails(String name, String rollNo) {
        System.out.println("Name: " + name);
        System.out.println("RollNo: " + rollNo);
    }
}
