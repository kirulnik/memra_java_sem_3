package ru.mirea.ex15;

public class EmployeeView {
    public void printEmployeeDetails(String post, double salary) {
        System.out.println("Должность сотрудника: " + post);
        System.out.println("Зарплата: " + salary);
    }
    public void printOperation(String str) {
        System.out.println("Выполнена операция: " + str);
    }
}
