package ru.mirea.ex15;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class MVCPatternDemoAirport {
    public static void main(String[] args) {
        Airport airport = new Airport("AA101", "JFK", "30");
        AirportView view = new AirportView(airport.getFlightNumber(), airport.getAirportCode(), airport.getTime());
        AirportController controller = new AirportController(airport, view);
        JButton updateButton = new JButton("Update Delay Time");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.updateAirportDetails();
            }
        });
        view.frame.getContentPane().add(updateButton, BorderLayout.SOUTH);
    }
}
