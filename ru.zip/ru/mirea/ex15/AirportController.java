package ru.mirea.ex15;

public class AirportController {
    private Airport model;
    private AirportView view;
    public AirportController(Airport model, AirportView view) {
        this.model = model;
        this.view = view;
    }
    public void updateAirportDetails() {
        // logic to get updated airport details
        String flightNumber = model.getFlightNumber();
        String airportCode = model.getAirportCode();
        String time = model.getTime();
        model = new Airport(flightNumber, airportCode, time);
        view.updateView(model);
    }
}
