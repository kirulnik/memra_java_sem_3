package ru.mirea.ex15;

import javax.swing.*;
import java.awt.*;
class AirportView {
    JFrame frame;
    private JLabel flightNumberLabel;
    private JLabel airportCodeLabel;
    private JLabel timeLabel;
    public AirportView(String flightNumber, String airportCode, String time) {
        frame = new JFrame("Airport View");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        flightNumberLabel = new JLabel("Flight Number: ");
        airportCodeLabel = new JLabel("Airport Code: ");
        timeLabel = new JLabel("Delay Time: ");
        panel.add(flightNumberLabel);
        panel.add(new JLabel(flightNumber));
        panel.add(airportCodeLabel);
        panel.add(new JLabel(airportCode));
        panel.add(timeLabel);
        panel.add(new JLabel(time));
        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }
    public void updateView(Airport airport) {
        flightNumberLabel.setText("Flight Number: " + airport.getFlightNumber());
        airportCodeLabel.setText("Airport Code: " + airport.getAirportCode());
        timeLabel.setText("Delay Time: " + airport.getTime());
    }
}
