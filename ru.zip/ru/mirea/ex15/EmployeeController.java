package ru.mirea.ex15;

public class EmployeeController {
    private Employee model;
    private EmployeeView view;
    public EmployeeController(Employee model, EmployeeView view){
        this.model=model;
        this.view=view;
    }
    public void setEmployeePost(String post){
        model.setPost(post);
    }
    public String getEmployeePost(){
        return model.getPost();
    }
    public void setEmployeeSalary(double salary){
        model.setSalary(salary);
    }
    public double getEmployeeSalary(){
        return model.getSalary();
    }
    public void updateView(){
        view.printEmployeeDetails(model.getPost(), model.getSalary());
    }
    public void oms(){
        model.setSalary(model.getSalary() - model.getSalary() * 0.05);
    }
    public void nds(){
        model.setSalary(model.getSalary() - model.getSalary() * 0.13);
    }
    public void showLogs(String num_of_operating){
        switch (num_of_operating) {
            case "1":
                view.printOperation("Вычитание ОИС");
                break;
            case "2":
                view.printOperation("Вычитание НДС");
                break;
            default:
                view.printOperation(num_of_operating);
                break;
        }
    }
}
