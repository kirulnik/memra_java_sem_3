package ru.mirea.ex15;

public class MVCPatternDemoEmployee {
    public static void main(String[] args) {
        Employee model = retriveEmployeeFromDatabase();
        EmployeeView view = new EmployeeView();
        EmployeeController controller = new EmployeeController(model, view);
        controller.updateView();
        controller.nds(); //Вычитаем ОМС
        controller.showLogs("1");
        controller.oms(); //Вычитаем НДС
        controller.showLogs("2");
        System.out.println("-----После обновления данных:------");
        controller.updateView();
        controller.showLogs("Завершение расчёта по сотруднику");
    }
    public static Employee retriveEmployeeFromDatabase() {
        Employee employee = new Employee();
        employee.setPost("Начальник Отдела");
        employee.setSalary(200000);
        return employee;
    }
}
