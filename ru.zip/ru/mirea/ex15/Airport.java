package ru.mirea.ex15;

public class Airport {
    private String flightNumber;
    private String airportCode;
    private String time;
    public Airport(String flightNumber, String airportCode, String time) {
        this.flightNumber = flightNumber;
        this.airportCode = airportCode;
        this.time = time;
    }
    public String getFlightNumber() {
        return flightNumber;
    }
    public String getAirportCode() {
        return airportCode;
    }
    public String getTime() {
        return time;
    }
}



