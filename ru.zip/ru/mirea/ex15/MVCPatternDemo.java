package ru.mirea.ex15;

public class MVCPatternDemo {
    public static void main(String[] args) {
        Student model = retriveStudentFromDatabase();
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);

        controller.updateView();

        controller.setStudentRollNo("25");
        System.out.println("-----После обновления данных:------");

        controller.updateView();

    }
    public static Student retriveStudentFromDatabase() {
        Student student = new Student();
        student.setName("Иван Иванов");
        student.setRollNo("36");
        return student;
    }
}
