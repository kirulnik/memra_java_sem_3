package ru.mirea.ex14;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentLinkedQueue;
public class WaitList<E> implements IWaitList<E> {
    protected ConcurrentLinkedQueue<E> content;
    public WaitList(){
        content = new ConcurrentLinkedQueue<E>();
    }
    public WaitList(Collection <E> c){
        content = new ConcurrentLinkedQueue<E>(c);
    }
    @Override
    public String toString(){
        return "WaitList: "+content;
    }
    @Override
    public void add(E element){
        content.add(element);
    }
    @Override
    public E remove(){
        if(!isEmpty()){
            return content.remove();
        }
        System.out.println("Очередь пуста!");
        return null;
    }
    @Override
    public boolean contains(E element) {
        boolean flag = false;
        for (int i = 0; i<content.size(); i++){
            E el = content.remove();
            if (el.equals(element)){
                flag = true;
                content.add(el);
            }
        }
        return flag;
    }
    @Override
    public boolean containsAll(Collection<E> c){
        ArrayList<E> arrayList = new ArrayList<>(c);
        for(int i = 0; i <c.size(); i++){
            boolean flag = false;
            for (int j = 0; j<content.size(); j++){
                E el = content.remove();
                if(el.equals(arrayList.get(i))){
                    flag = true;
                    content.add(el);
                }
            }
            if(!flag){
                return false;
            }
        }
        return true;
    }
    @Override
    public boolean isEmpty(){
        return content.isEmpty();
    }
}
