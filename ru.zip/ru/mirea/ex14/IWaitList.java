package ru.mirea.ex14;
import java.util.Collection;

/**
 * @param <E>
 * @author tardasov_kirill(skets)
 */
public interface IWaitList<E> {
    /**
     *
     * @param element element
     */
    void add(E element);

    /**
     * @return Removed element
     */
    E remove();

    /**
     * @param element Value to check
     * @return True - element found, False - not found
     */
    boolean contains(E element);


    /**
     * @param c
     * @return True - found all elements, false - not all elements found
     */
    boolean containsAll(Collection<E> c);

    /**
     * @return True - there is no elements, false - there are some elements
     */
    boolean isEmpty();
}
