package ru.mirea.ex14;

import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        WaitList <Integer> waitList = new WaitList<>();
        ArrayList <Integer> arrayList = new ArrayList<>();
        BoundedWaitList <Integer> boundedWaitList= new BoundedWaitList<>(5);
        UnfairWaitList <Integer> unfairWaitList = new UnfairWaitList<>();
        waitList.add(24); waitList.add(2);
        waitList.add(19); waitList.add(20);
        waitList.add(13);
        System.out.println(waitList.toString());
        System.out.println("WaitList: 19? "+waitList.contains(19));
        System.out.println("WaitList: 13? "+waitList.contains(13));
        System.out.println("WaitList: isEmpty? "+waitList.isEmpty());
        arrayList.add(0);
        System.out.println("WaitList: 0? "+waitList.containsAll(arrayList));
        System.out.println("------------------------------");
        boundedWaitList.add(100);
        boundedWaitList.add(101);
        boundedWaitList.add(102);
        boundedWaitList.add(103);
        boundedWaitList.add(104);
        System.out.println(boundedWaitList);
        boundedWaitList.add(105);
        boundedWaitList.remove();
        System.out.println(boundedWaitList);
        boundedWaitList.add(555);
        System.out.println(boundedWaitList);
        System.out.println("Max size BoundedWaitList: "+boundedWaitList.getCapacity());
        System.out.println("------------------------------");
        unfairWaitList.add(10000);
        unfairWaitList.add(20000);
        unfairWaitList.add(30000);
        unfairWaitList.add(40000);
        unfairWaitList.add(50000);
        System.out.println(unfairWaitList);
        unfairWaitList.remove(50000);
        unfairWaitList.remove(20000);
        System.out.println(unfairWaitList);
        unfairWaitList.moveToBack(30000);
        System.out.println(unfairWaitList);
    }
}

