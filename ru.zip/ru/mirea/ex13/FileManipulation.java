package ru.mirea.ex13;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;

public class FileManipulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Реализация записи в файл введенной с клавиатуры информации
        try {
            FileWriter writer = new FileWriter("output.txt");
            System.out.println("Введите информацию для записи в файл:");
            String input = scanner.nextLine();
            writer.write(input);
            writer.close();
            System.out.println("Информация успешно записана в файл.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 2. Реализация вывода информации из файла на экран
        try {
            FileReader reader = new FileReader("output.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            System.out.println("Информация из файла:");
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 3. Замена информации в файле на информацию, введенную с клавиатуры
        try {
            FileWriter writer = new FileWriter("output.txt");
            System.out.println("Введите информацию для замены в файле:");
            String replacement = scanner.nextLine();
            writer.write(replacement);
            writer.close();
            System.out.println("Информация в файле успешно заменена.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 4. Добавление в конец исходного файла текста, введенного с клавиатуры
        try {
            FileWriter writer = new FileWriter("output.txt", true); // Устанавливаем параметр append в true
            System.out.println("Введите текст для добавления в конец файла:");
            String appendText = scanner.nextLine();
            writer.write(appendText);
            writer.close();
            System.out.println("Текст успешно добавлен в конец файла.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

