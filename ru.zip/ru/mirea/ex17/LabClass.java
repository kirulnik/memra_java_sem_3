package ru.mirea.ex17;

import java.util.ArrayList;
public class LabClass {
    public static void main(String[] args) {
        ArrayList<Student> student = new ArrayList<>();
        student.add(new Student("Тардасов К.Е.", 240204, 4.2));
        new LabClassGUI(student);
    }
}

