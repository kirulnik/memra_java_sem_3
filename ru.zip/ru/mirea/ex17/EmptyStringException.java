package ru.mirea.ex17;

import javax.swing.*;
public class EmptyStringException extends IllegalArgumentException{
    public EmptyStringException(LabClassGUI gui){
        JOptionPane.showMessageDialog(gui, "Пустая строка!");
    }
}

