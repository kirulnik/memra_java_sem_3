package ru.mirea.ex17;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Objects;

public class LabClassGUI extends JFrame {
    private ArrayList<Student> studentArrayList;
    private JTable table;
    private DefaultTableModel tableModel;
    public LabClassGUI(ArrayList<Student> studentArrayList) {
        this.studentArrayList = studentArrayList;
        setTitle("Студенты");
        JButton addButton = new JButton("Добавить");
        JButton delButton = new JButton("Удалить");
        JButton GPAButton = new JButton("Отсортировать по GPA");
        JButton searchButton = new JButton("Найти");
        JPanel panel = new JPanel(new FlowLayout());
        setSize(700, 700);
        panel.add(addButton);
        panel.add(delButton);
        panel.add(GPAButton);
        panel.add(searchButton);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(panel, BorderLayout.NORTH);
        setVisible(true);

        Object [][] tableStudent = new Object[studentArrayList.size()][3];
        for(int i = 0; i < studentArrayList.size(); i++){
            tableStudent[i][0] = studentArrayList.get(i).getSurname();
            tableStudent[i][1] = studentArrayList.get(i).getId();
            tableStudent[i][2] = studentArrayList.get(i).getGPA();
        }
        table = new JTable(new DefaultTableModel(tableStudent, new String[] {"ФИО", "ID", "GPA"}));
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
        updateTable();

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addStudent();
            }
        });
        delButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteStudent();
            }
        });
        GPAButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortingStudentByGPA();
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchStudentBySurname();
            }
        });
    }
    private void addStudent(){
        String surname = JOptionPane.showInputDialog("ФИО");
        if(surname.isEmpty()){
            throw new EmptyStringException(this);
        }
        String id = JOptionPane.showInputDialog("ID");
        if(id.isEmpty()){
            throw new EmptyStringException(this);
        }
        String gpa = JOptionPane.showInputDialog("GPA");
        if(gpa.isEmpty()){
            throw new EmptyStringException(this);
        }
        Student addStudent = new Student(surname, Integer.parseInt(id), Double.parseDouble(gpa));
        studentArrayList.add(addStudent);
        updateTable();
    }
    private void deleteStudent(){
        String surname = JOptionPane.showInputDialog("Введите ФИО студента");
        if(surname.isEmpty()){
            throw new EmptyStringException(this);
        }
        for(int i = 0; i < studentArrayList.size(); i++){
            if(Objects.equals(studentArrayList.get(i).getSurname(), surname)){
                studentArrayList.remove(i);
                updateTable();
                return;
            }
        }
        new StudentNotFoundException(surname, this);
    }
    private void sortingStudentByGPA(){
        studentArrayList.sort((s1, s2) ->Double.compare(s2.getGPA(), s1.getGPA()));
        updateTable();
    }
    private void searchStudentBySurname(){
        String surname = JOptionPane.showInputDialog("Введите ФИО студента");
        if(surname.isEmpty()){
            throw new EmptyStringException(this);
        }
        for(int i = 0; i < studentArrayList.size(); i++){
            if(Objects.equals(studentArrayList.get(i).getSurname(), surname)){
                Student student = studentArrayList.get(i);
                Object[][] tableStudent = new Object[1][3];
                tableStudent[0][0] = student.getSurname();
                tableStudent[0][1] = student.getId();
                tableStudent[0][2] = student.getGPA();
                String[] names = {"ФИО", "ID", "GPA"};
                if(tableModel == null){
                    tableModel = new DefaultTableModel(tableStudent, names);
                    table = new JTable(tableModel);
                    JScrollPane scrollPane = new JScrollPane(table);
                    add(scrollPane, BorderLayout.CENTER);
                }
                else{
                    tableModel.setDataVector(tableStudent, names);
                }
                revalidate();
                repaint();
                return;
            }
        }
        new StudentNotFoundException(surname, this);
    }
    private void updateTable(){
        Object [][] tableStudent = new Object[studentArrayList.size()][3];
        for(int i = 0; i < studentArrayList.size(); i++){
            Student student = studentArrayList.get(i);
            tableStudent[i][0] = student.getSurname();
            tableStudent[i][1] = student.getId();
            tableStudent[i][2] = student.getGPA();
        }
        String[] names = {"ФИО", "Номер", "GPA"};
        if(tableModel == null) {
            tableModel = new DefaultTableModel(tableStudent, names);
            table = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(table);
            add(scrollPane, BorderLayout.CENTER);
        }
        else{
            tableModel.setDataVector(tableStudent, names);
        }
        revalidate();
        repaint();
    }
}
