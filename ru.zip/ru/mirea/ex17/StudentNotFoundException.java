package ru.mirea.ex17;

import javax.swing.*;
public class StudentNotFoundException extends Exception{
    public StudentNotFoundException(String fio, LabClassGUI gui){
        JOptionPane.showMessageDialog(gui, "Студент "+fio+" не найден!");
    }
}

