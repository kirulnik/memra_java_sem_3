package ru.mirea.ex17;

import java.util.Scanner;
public class MainExINN {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите Ваше ФИО");
        String fio = scanner.nextLine();
        System.out.println("Введите Ваш ИНН");
        String inn = scanner.nextLine();
        try {
            validateINN(inn);
            System.out.println("Заказ оформлен успешно");
        } catch (ExceptionINN e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }
    public static void validateINN(String inn) throws ExceptionINN {
        if (inn.length() != 12) {
            throw new ExceptionINN("ИНН должен состоять из 12 цифр");
        }
        try {
            Long.parseLong(inn);
        } catch (NumberFormatException e) {
            throw new ExceptionINN("ИНН должен состоять только из цифр");
        }
    }
}

