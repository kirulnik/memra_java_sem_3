package ru.mirea.ex17;

public class ExceptionINN extends Exception{
    public ExceptionINN(String message){
        super(message);
    }
}
