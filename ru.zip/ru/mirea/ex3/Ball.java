package ru.mirea.ex3;

public class Ball {
    protected String type;
    protected int radius;
    public int getRadius() {
        return radius;
    }

    public String getType() {
        return type;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Ball(String type, int radius) {
        this.type = type;
        this.radius = radius;
    }

    public Ball(String type) {
        this.type = type;
        this.radius = 0;
    }

    public Ball(int radius) {
        this.radius = radius;
        this.type = "NoneType";
    }

    public Ball() {
        this.radius = 0;
        this.type = "NoneType";
    }

    @Override
    public String toString() {
        return "Ball {" +
                "type='" + type + '\'' +
                ", radius=" + radius +
                '}';
    }

    public void getCapacity() {
        System.out.println("Объем мяча: " + Math.PI * Math.pow(radius,3)*4/3);
    }
}

