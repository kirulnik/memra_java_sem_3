package ru.mirea.ex3;

import java.lang.*;
public class TestBall {
    public static void main(String[] args) {
        Ball ball = new Ball("Voleyball",7);
        System.out.println(ball);
        ball.setRadius(8);
        ball.setType("Football");
        System.out.println(ball);
        ball.getCapacity();
    }
}

