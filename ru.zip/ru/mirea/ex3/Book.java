package ru.mirea.ex3;


public class Book {
    protected String item;
    protected String author;
    protected int price;
    public Book(String item, String author, int price) {
        this.item = item;
        this.author = author;
        this.price = price;
    }
    public Book() {
        this.item = "Undefined";
        this.author = "Undefined";
        this.price = 0;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public String getAuthor() {
        return author;
    }

    public String getItem() {
        return item;
    }

    @Override
    public String toString() {
        return "Book{" +
                "item='" + item + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                '}';
    }
    public void getDiscount(int percent) {
        System.out.println("Скидка: " + price * percent / 100 + "%");
    }

}


