package ru.mirea.ex3;


import java.lang.*;
public class TestBook {
    public static void main(String[] args) {
        Book book = new Book("Евгений Онегин", "Пушкин А.С.", 200);
        System.out.println(book);
        System.out.println("Текущая цена: " + book.getPrice() + " у.е.");
        book.setPrice(500);
        System.out.println("Новая цена: " + book.getPrice() + " у.е.");
        book.getDiscount(5);
    }
}

