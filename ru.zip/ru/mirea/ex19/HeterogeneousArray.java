package ru.mirea.ex19;

public class HeterogeneousArray {
    private Object[] array;
    public HeterogeneousArray(int size) {
        this.array = new Object[size];
    }
    public void add(int index, Object element) {
        array[index] = element;
    }
    public Object get(int index) {
        return array[index];
    }
    public static void main(String[] args) {
        HeterogeneousArray array = new HeterogeneousArray(5);
        array.add(0, 10);
        array.add(1, 20L);
        array.add(2, "Hello");
        array.add(3, 3.14);
        array.add(4, true);

        System.out.println(array.get(0)); // Output: 10
        System.out.println(array.get(1)); // Output: 20
        System.out.println(array.get(2)); // Output: Hello
        System.out.println(array.get(3)); // Output: 3.14
        System.out.println(array.get(4)); // Output: true
    }
}
