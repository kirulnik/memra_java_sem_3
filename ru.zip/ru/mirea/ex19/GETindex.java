package ru.mirea.ex19;

public class GETindex {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        int index = 3;
        System.out.println(getElement(arr, index));
    }
    public static int getElement(int[] arr, int index) {
        if (index >= 0 && index < arr.length) {
            return arr[index];
        } else {
            throw new IllegalArgumentException("Invalid index");
        }
    }
}
