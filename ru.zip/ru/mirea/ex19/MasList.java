package ru.mirea.ex19;

import java.util.ArrayList;
public class MasList<T> {
    public static <T> ArrayList<T> convertArrToList(T[] arr) {
        if (arr != null) {
            ArrayList<T> converted_list = new ArrayList<>();
            for (int i=0; i < arr.length;i++) {
                converted_list.add((T) arr[i]);
            }
            return converted_list;
        }
        else {
            throw new RuntimeException("Массив пуст");
        }
    }
    public static void main(String[] args) {
        Integer[] arr_int = new Integer[]{24,19, 12, 100};
        System.out.println(convertArrToList(arr_int));
    }
}

