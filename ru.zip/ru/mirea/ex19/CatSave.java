package ru.mirea.ex19;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class CatSave {
    public static void main(String[] args) {
        try {
            File directory = new File("D:/javasave/1/2/3");
            List<String> filesList = listFilesUsingJavaIO(directory);
            printFirstFiveFiles(filesList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static List<String> listFilesUsingJavaIO(File directory) throws IOException {
        List<String> result = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(Paths.get(directory.getAbsolutePath()))) {
            result = paths
                    .filter(Files::isRegularFile)
                    .map(Path::toString)
                    .collect(Collectors.toList());
        }
        return result;
    }
    private static void printFirstFiveFiles(List<String> filesList) {
        for (int i = 0; i < Math.min(5, filesList.size()); i++) {
            System.out.println(filesList.get(i));
        }
    }
}
