package ru.mirea.ex1old;

public class Exercise1P3 {
    public static void main(String[] args) {
        int arf = 0;
        int sum = 0;
        int[] ex3 = {1, -69, 420, 24022004};
        for(int i = 0; i< ex3.length; i++) {
            sum = sum + ex3[i];
        }
        arf = sum/ex3.length;
        System.out.println("Сумма чисел массива: " + sum);
        System.out.println("Среднее арифметическое чисел массива: " + arf);
    }

}
