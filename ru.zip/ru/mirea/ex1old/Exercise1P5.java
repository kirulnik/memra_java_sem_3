package ru.mirea.ex1old;

public class Exercise1P5 {
    public static void main(String[] args) {
        // Перебираем все аргументы командной строки с помощью цикла for
        for (int i = 0; i < args.length; i++) {
            System.out.println("Аргумент " + (i + 1) + ": " + args[i]);
        }
    }
}
