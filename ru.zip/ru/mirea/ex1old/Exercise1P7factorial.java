package ru.mirea.ex1old;

public class Exercise1P7factorial {
    public static void main(String[] args) {
        int number = 21; //Задаем число, для которого хотим вычислить факториал
        if(number>20 | number<0) System.out.println("Факториал для данного числа рассчитать невозможно!");
        else{
            long factorial = calculateFactorial(number); //Вызываем метод для вычисления факториала
            System.out.println("Факториал числа " + number + " равен " + factorial);
        }
    }

    public static long calculateFactorial(int n) {
        long factorial = 1;
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        return factorial;
    }
}
