package ru.mirea.ex1old;

import java.util.Scanner;
public class ProgramP1Ex1 {
    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }
    public static void main(String[] args) {
        Scanner tk = new Scanner(System.in);
        System.out.println("Введите количество элементов массива (целые числа):");
        int i = 0;
        int min = 0;
        int o = 0;
        int max = 0;
        int sum = 0;
        if(tk.hasNextInt())  {
            o = tk.nextInt();
            if (o > 0) {
                int[] ktm = new int[o];
                while (i < o) {
                    String j = tk.next();
                    if (isNumeric(j)) {
                        ktm[i] = Integer.parseInt(j);
                        if (i == 0) {
                            min = ktm[i];
                        }
                        if (min >= ktm[i]) {
                            min = ktm[i];
                        }

                        if (i == 0) {
                            max = ktm[i];
                        }
                        if (max <= ktm[i]) {
                            max = ktm[i];
                        }
                        i++;
                    }
                }
                i = 0;
                do {
                    sum = sum + ktm[i];
                    i++;
                }while(i < o);
                System.out.println("Минимальное число массива: " + min);
                System.out.println("Максимальное число массива: "+ max);
                System.out.println("Сумма чискл массива: " + sum);
            }

        }
        else System.out.println("Вы ввели не целое число!");
    }
}
