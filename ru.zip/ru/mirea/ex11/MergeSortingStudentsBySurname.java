package ru.mirea.ex11;

import java.util.Comparator;
public class MergeSortingStudentsBySurname implements Comparator<Student> {

    @Override
    public int compare(Student s1, Student s2) {
        return s1.getSurname().compareTo(s2.getSurname());
    }
    public void mergeSort(Student[] s, int n) {
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        Student[] left = new Student[mid];
        Student[] right = new Student[n - mid];
        for (int i = 0; i < mid; i++) {
            left[i] = s[i];
        }
        for (int i = mid; i < n; i++) {
            right[i - mid] = s[i];
        }
        mergeSort(left, mid);
        mergeSort(right, n - mid);
        merge(s, left, right, mid, n - mid);
    }
    public void merge(Student[] a, Student[] l, Student[] rightA, int left, int right) {
        int i = 0, j = 0, k = 0;
        while (i < left && j < right) {
            if (compare(l[i],rightA[j]) <= 0) {
                a[k++] = l[i++];
            }
            else {
                a[k++] = rightA[j++];
            }
        }
        while (i < left) {
            a[k++] = l[i++];
        }
        while (j < right) {
            a[k++] = rightA[j++];
        }
    }
}

