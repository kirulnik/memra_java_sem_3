package ru.mirea.ex11;

import java.util.Comparator;
public class SortingStudentsByGPA implements Comparator<Student> {

    @Override
    public int compare(Student s1, Student s2) {
        return Double.compare(s1.getGPA(), s2.getGPA());
    }
    public void QuickSort(Student[] arr, int begin, int end){
        if (begin < end){
            int partindex = part(arr, begin, end);
            QuickSort(arr, begin, partindex-1);
            QuickSort(arr, partindex+1, end);
        }
    }
    public int part(Student[] arr, int begin, int end){
        Student pt = arr[end];
        int i = begin-1;
        for (int j = begin; j < end; j++) {
            if (compare(arr[j], pt) >= 0) {
                i++;
                Student s = arr[i];
                arr[i] = arr[j];
                arr[j] = s;
            }
        }
        Student s = arr[i+1];
        arr[i+1] = arr[end];
        arr[end] = s;
        return i+1;
    }
}

