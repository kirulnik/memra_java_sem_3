package ru.mirea.ex11;

public class TestClass {
    public static void main(String[] args) {
        Student[] studentsArr1 = new Student[]{
                new Student("Смирнов", 22301, 4.87),
                new Student("Соболев", 50385, 3.33),
                new Student("Емельянов", 33078, 4.23),
                new Student("Фролов", 48292, 4.02),
                new Student("Иванов", 44908, 4.77)
        };
        Student[] studentsArr2 = new Student[]{
                new Student("Королев", 35689, 3.32),
                new Student("Фёдоров", 13553, 4.34),
                new Student("Синичкин", 43224, 4.23),
                new Student("Кириллов", 15702, 4.11),
                new Student("Мирзоян", 33413, 4.89)
        };
        System.out.println("---------------Исходный массив---------------");
        for(int i = 0; i < studentsArr1.length; i++){
            System.out.println(studentsArr1[i].toString());
        }
        for (int i = 0; i < studentsArr1.length; i++){
            Student temp = studentsArr1[i];
            int j = i - 1;
            while (j >= 0 && studentsArr1[j].getId() > temp.getId()){
                studentsArr1[j+1] = studentsArr1[j];
                j--;
            }
            studentsArr1[j+1] = temp;
        }
        System.out.println("---------------Массив, отсортированный вставками по ID---------------");
        for (int i = 0; i < studentsArr1.length; i++){
            System.out.println(studentsArr1[i].toString());
        }

        System.out.println("---------------Исходный массив---------------");
        for(int i = 0; i < studentsArr2.length; i++){
            System.out.println(studentsArr2[i].toString());
        }
        SortingStudentsByGPA s = new SortingStudentsByGPA();
        s.QuickSort(studentsArr2, 0, studentsArr2.length-1);
        System.out.println("---------------Массив, отсортированный слиянием по GPA в порядке убывания---------------");
        for (int i = 0; i < studentsArr2.length; i++) {
            System.out.println(studentsArr2[i].toString());
        }

        Student[] newArr = new Student[studentsArr1.length + studentsArr2.length];
        System.arraycopy(studentsArr1, 0, newArr, 0, studentsArr1.length);
        System.arraycopy(studentsArr2, 0, newArr, studentsArr1.length, studentsArr2.length);
        System.out.println("---------------Исходный объединенный массив---------------");
        for (int i = 0; i < newArr.length; i++){
            System.out.println(newArr[i].toString());
        }
        MergeSortingStudentsBySurname m = new MergeSortingStudentsBySurname();
        m.mergeSort(newArr, newArr.length);
        System.out.println("---------------Отсортированный слиянием объединенный массив---------------");
        for (int i = 0; i < newArr.length; i++){
            System.out.println(newArr[i].toString());
        }
    }
}

