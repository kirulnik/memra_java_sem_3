package ru.mirea.ex11;

public class Student {
    private String surname;

    private int id;

    private double GPA;

    public Student(String surname, int id, double GPA){
        this.surname = surname;
        this.id = id;
        this.GPA = GPA;
    }

    public double getGPA() {
        return GPA;
    }
    public void setGPA(double GPA) {
        this.GPA = GPA;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getSurname() {
        return surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Override
    public String toString() {
        return "surname - "+getSurname()+", ID - "+getId()+", GPA = "+getGPA();
    }
}

