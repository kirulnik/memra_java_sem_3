package ru.mirea.ex12;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class DrinkerPlay {
    public static void main(String[] args) {
        System.out.println("Игра <Пьяница>. У каждого игрока по 5 карт. Все карты уникальные от 0 до 9");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите 5 карт первого игрока:");
        // Проверяем, что вводим только цифры
        if (!scanner.hasNextInt()) {
            System.out.println("Ошибка ввода. Присутствуют не игровые карты!");
            return;
        }
        String first = scanner.nextLine();
        System.out.println("Введите 5 карт второго игрока:");
        // Проверяем, что вводим только цифры
        if (!scanner.hasNextInt()) {
            System.out.println("Ошибка ввода. Присутствуют не игровые карты!");
            return;
        }
        String second = scanner.nextLine();
        // Проверяем, что у каждого игрока ровно по 5 карт
        if (first.length() != 5 || second.length() != 5) {
            System.out.println("Ошибка ввода. Не у каждого игрока по 5 карт!");
            return;
        }
        // Проверяем, что все карты уникальные
        int p1 = Integer.parseInt(first);
        int p2 = Integer.parseInt(second);
        int[] arr = new int[10];
        for (int i = 0; i < 5; i++) {
            arr[p1 % 10] += 1;
            arr[p2 % 10] += 1;
            p1 /= 10;
            p2 /= 10;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 1) {
                System.out.println("Ошибка ввода. Не все карты уникальные");
                return;
            }
        }
        // Создаем очереди (Queue) для карт игроков
        Queue<Integer> firstQUEUE = new LinkedList<>();
        Queue<Integer> secondQUEUE = new LinkedList<>();
        // Заполняем очереди картами игроков
        for (int i = 0; i < 5; i++) {
            firstQUEUE.add(Integer.valueOf(first.charAt(i)));
            secondQUEUE.add(Integer.valueOf(second.charAt(i)));
        }
        int count = 0;
        // Моделируем игру пьяница
        while (count <= 106) {
            int firstCard = firstQUEUE.poll();
            int secondCard = secondQUEUE.poll();
            // Логика определения победителя
            if (firstCard == '0' && secondCard == '9') {
                firstQUEUE.add(firstCard);
                firstQUEUE.add(secondCard);
            } else if (firstCard == '9' && secondCard == '0') {
                secondQUEUE.add(secondCard);
                secondQUEUE.add(firstCard);
            } else if (firstCard > secondCard) {
                firstQUEUE.add(firstCard);
                firstQUEUE.add(secondCard);
            } else if (secondCard > firstCard) {
                secondQUEUE.add(secondCard);
                secondQUEUE.add(firstCard);
            }
            count++;
            if (firstQUEUE.isEmpty()) {
                System.out.println("second " + count);
                return;
            }
            if (secondQUEUE.isEmpty()) {
                System.out.println("first " + count);
                return;
            }
        }
        System.out.println("botva");
    }
}

