package ru.mirea.ex10;

import java.util.Scanner;

public class Ex210 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите натуральное число: ");
        int number = scanner.nextInt();
        System.out.print("Цифры числа: ");
        printDigits(number);
    }

    public static void printDigits(int n) {
        if (n < 10) {
            System.out.print(n + " ");
        } else {
            printDigits(n / 10); // вызываем метод для числа без последней цифры
            System.out.print(n % 10 + " "); // выводим последнюю цифру
        }
    }
}



