package ru.mirea.ex10;

import java.util.Scanner;

public class Ex110 {
    public static void main(String[] args) {
        System.out.println("Введите число");
        readAndPrintNumbers();
    }

    public static void readAndPrintNumbers() {
        Scanner scanner = new Scanner(System.in);

        int count = 1;
        int number;

        // Считываем числа с клавиатуры и выводим первое, третье, пятое и т.д. число
        while ((number = scanner.nextInt()) != 0) {
            if (count % 2 != 0) {
                System.out.println(number);
            }
            count++;
        }
    }
}

