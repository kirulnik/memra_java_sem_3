package ru.mirea.ex10;

import java.util.Scanner;
public class Ex310 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите натуральное число: ");
        int number = scanner.nextInt();
        System.out.print("Цифры числа в обратном порядке: ");
        printDigitsReversed(number);
    }
    public static void printDigitsReversed(int n) {
        if (n < 10) {
            System.out.print(n + " ");
        } else {
            System.out.print(n % 10 + " "); // выводим последнюю цифру
            printDigitsReversed(n / 10); // вызываем метод для числа без последней цифры
        }
    }
}


