package ru.mirea.ex16;

import java.util.Scanner;
public class Exception5 {
    public void getDetails(String key) {
        if (key == null) {
            throw new NullPointerException("null key in getDetails");
        }
    }
    public String getDetails2(String key) {
        try {
            if (key == null) {
                throw new NullPointerException("null key in getDetails");
            }
        } catch (NullPointerException e) {}
        return "data for " + key;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите номер подзадачи!");
        switch(sc.nextInt()) {
            case 1:
                Exception5 test_exep = new Exception5();
                test_exep.getDetails(null);
                break;
            case 2:
                Exception5 test_exep2 = new Exception5();
                System.out.println(test_exep2.getDetails2(null));
                break;
        }
    }
}

