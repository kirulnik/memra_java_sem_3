package ru.mirea.ex16;

import java.util.Scanner;
public class Exception6 {
    public String getDetails(String key) {
        if (key == null) {
            throw new NullPointerException("null key in getDetails");
        }
        return "data for " + key;
    }
    public void printMessage(String key) {
        try {
            key = getDetails(key);
        }
        catch (Exception e){}
        System.out.println(key);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите номер подзадачи!");
        switch(sc.nextInt()) {
            case 1:
                Exception6 test_exep = new Exception6();
                test_exep.getDetails("Dreams");
                test_exep.getDetails(null);
                break;
            case 2:
                Exception6 test_exep2 = new Exception6();
                test_exep2.printMessage(null);
                test_exep2.printMessage("Дом");
                break;
        }
    }
}

