package ru.mirea.ex16;

import java.util.Scanner;
public class Exception4 {
    static public void exceptionDemoCatch() {
        try {
            Scanner myScanner = new Scanner( System.in);
            System.out.print( "Enter an integer ");
            String intString = myScanner.next();
            int i = Integer.parseInt(intString);
            System.out.println( 2 / i );
        }
        catch (NumberFormatException e) {
            System.out.println("Введено не число!");
        }
        finally {
            System.out.println("Отработал блок finally!");
        };
    }
    public static void main(String[] args) {
        exceptionDemoCatch();
    }
}

