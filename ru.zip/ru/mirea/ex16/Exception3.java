package ru.mirea.ex16;

import java.util.Scanner;
public class Exception3 {
    static public void exceptionDemoCatch() {
        try {
            Scanner myScanner = new Scanner(System.in);
            System.out.print("Enter an integer ");
            String intString = myScanner.next();
            int i = Integer.parseInt(intString);
            System.out.println(2 / i);
        } catch (Exception e) {
            System.err.print("Поймано исключение Exception");
        }
    }
    public static void main(String[] args) {
        exceptionDemoCatch();
    }
}

