package ru.mirea.ex16;

import java.util.Scanner;
public class Exception1 {
    static public void exceptionDemo() {
        System.out.println(2 / 0);
    }
    static public void exceptionDemoDouble() {
        System.out.println(2.0 / 0.0);
    }
    static public void exceptionDemoCatch() {
        try {
            System.out.println(2 / 0);
        } catch (ArithmeticException e) {
            System.out.println("Attempted division by zero");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите номер подзадачи!");
        switch(sc.nextInt()) {
            case 1:
                exceptionDemo(); //Exception in thread "main" java.lang.ArithmeticException: / by zero
                break;
            case 2:
                exceptionDemoDouble(); //Infinity
                break;
            case 3:
                exceptionDemoCatch(); //Attempted division by zero
                break;
        }
    }
}

