package ru.mirea.ex16;

import java.util.Scanner;
public class Exception2 {
    static public void exceptionDemo() {
        Scanner myScanner = new Scanner( System.in);
        System.out.print( "Enter an integer ");
        String intString = myScanner.next();
        int i = Integer.parseInt(intString);
        System.out.println( 2/i );
    }
    static public void exceptionDemoCatch() {
        try {
            Scanner myScanner = new Scanner( System.in);
            System.out.print( "Enter an integer ");
            String intString = myScanner.next();
            int i = Integer.parseInt(intString);
            System.out.println( 2 / i );
        }
        catch (NumberFormatException e) {
            System.out.println("Введено не число!");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите номер подзадачи!");
        switch(sc.nextInt()) {
            case 1:
                exceptionDemo();
                break;
            case 2:
                exceptionDemoCatch();
                break;
        }
    }
}

