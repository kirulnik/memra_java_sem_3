package ru.mirea.ex9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tablo extends JFrame implements ActionListener {

    private int milanScore = 0;
    private int madridScore = 0;

    private JLabel resultLabel, lastScorerLabel, winnerLabel;

    public Tablo() {
        setTitle("Тайм/Период");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton milanButton = new JButton("AC Milan");
        JButton madridButton = new JButton("Real Madrid");

        milanButton.addActionListener(this);
        madridButton.addActionListener(this);

        milanButton.setBackground(Color.RED); // Цвет фона
        milanButton.setForeground(Color.WHITE); // Цвет текста
        madridButton.setBackground(Color.BLUE); // Цвет фона
        madridButton.setForeground(Color.WHITE); // Цвет текста

        resultLabel = new JLabel("Счёт: 0 X 0", SwingConstants.CENTER);
        lastScorerLabel = new JLabel("Последний забивший: N/A", SwingConstants.CENTER);
        winnerLabel = new JLabel("НИЧЬЯ", SwingConstants.CENTER);

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(milanButton);
        panel.add(madridButton);
        panel.add(resultLabel);
        panel.add(lastScorerLabel);
        panel.add(winnerLabel);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("AC Milan")) {
            milanScore++;
            updateResult("AC Milan");
        } else if (e.getActionCommand().equals("Real Madrid")) {
            madridScore++;
            updateResult("Real Madrid");
        }
    }

    private void updateResult(String lastScorer) {
        resultLabel.setText("Счёт: " + milanScore + " X " + madridScore);
        lastScorerLabel.setText("Последний забивший: " + lastScorer);

        if (milanScore > madridScore) {
            winnerLabel.setText("Ведёт: AC Milan");
        } else if (madridScore > milanScore) {
            winnerLabel.setText("Ведёт: Real Madrid");
        } else {
            winnerLabel.setText("НИЧЬЯ");
        }
    }

    public static void main(String[] args) {
        new Tablo();
    }
}

