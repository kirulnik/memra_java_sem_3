package ru.mirea.ex21;

public class TestLinkedQueue {
    public static void main(String[] args) {
        LinkedQueue queue_1 = new LinkedQueue();
        queue_1.enqueue(1);
        queue_1.enqueue(2);
        queue_1.enqueue(3);
        System.out.println(queue_1.dequeue());
        System.out.println(queue_1.element());
        System.out.println(queue_1.dequeue());
        System.out.println("Пусто - "+ queue_1.isEmpty());
        System.out.println(queue_1.dequeue());
        System.out.println("Пусто - "+ queue_1.isEmpty());
    }
}

