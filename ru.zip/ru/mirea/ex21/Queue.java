package ru.mirea.ex21;

public interface Queue {
    void enqueue(Object o);
    Object element();
    Object dequeue();
    boolean isEmpty();
    void clear();
}
