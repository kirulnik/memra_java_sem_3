package ru.mirea.ex21;


public class TestArrayQueue {
    public static void main(String[] args) {
        ArrayQueueModule queue_1 = ArrayQueueModule.getObj();
        queue_1.enqueue(24);
        queue_1.enqueue(20);
        queue_1.enqueue(4);
        queue_1.enqueue(69);
        queue_1.enqueue(420);
        System.out.println(queue_1.dequeue());
        System.out.println("Пусто - "+ queue_1.isEmpty());
        ArrayQueueADT queue_2 = new ArrayQueueADT(queue_1);
        System.out.println(queue_2.dequeue());
        System.out.println(queue_2.element());
        System.out.println(queue_2.dequeue());
        System.out.println("Пусто - "+ queue_2.isEmpty());
        ArrayQueue queue_3 = new ArrayQueue();
        System.out.println(queue_3.dequeue());
        System.out.println(queue_3.dequeue());
        System.out.println("Пусто - "+ queue_3.isEmpty());
    }
}

