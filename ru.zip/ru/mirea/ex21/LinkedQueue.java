package ru.mirea.ex21;

import java.util.LinkedList;
public class LinkedQueue extends AbstractQueue implements Queue {
    private LinkedList<Object> queue;
    public LinkedQueue(){
        queue = new LinkedList<>();
        front = 0;
        rear = 0;
    }
    @Override
    public void enqueue(Object val) {
        queue.add(val);
        rear++;
    }
    @Override
    public Object dequeue() {
        if(isEmpty()) throw new IndexOutOfBoundsException("Очередь пуста!");
        System.out.println(front + " " + rear);
        return queue.remove(front);
    }
    @Override
    public Object element() {
        if(isEmpty()) throw new IndexOutOfBoundsException("Очередь пуста!");
        return  queue.get(front);
    }
    @Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }
    @Override
    public void clear() {
        queue.clear();
        front = 0;
        rear = 0;
    }
}

