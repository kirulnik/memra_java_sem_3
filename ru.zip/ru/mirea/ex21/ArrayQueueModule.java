package ru.mirea.ex21;

public class ArrayQueueModule {
    // Инвариант класса: 0 <= SIZE < items.length
    int SIZE = 6;
    Object[] items;
    int front, rear;
    private static ArrayQueueModule obj;
    //Пред.: items = null; Пост.:items.length = 6
    public ArrayQueueModule(){
        items = new Object[SIZE];
    }
    //Пред.: нет; Пост.:items[rear] = elem; items[rear-1]
    public void enqueue(Object elem) {
        items[rear] = elem;
        rear++;
        if (rear == items.length) rear = 0;
        if (rear == front) throw new ArrayStoreException("Очередь переполнена!");
    }
    //Пред.: SIZE > 0; Пост.:items[head]
    public Object element(){
        if (isEmpty()) throw new IndexOutOfBoundsException("Очередь пуста!");
        else return items[front];
    }
    //Пред.: SIZE > 0; Пост.:items[head+1]; items[head++]
    public Object dequeue() {
        if(isEmpty()) throw new IndexOutOfBoundsException("Очередь пуста!");
        if(front == items.length) front = 0;
        return items[front++];
    }
    //Пред.: нет; Пост.: front == rear
    public boolean isEmpty() {
        return front == rear;
    }
    public int size() {
        return items.length - 1;
    }
    public void clear(){
        front = 0;
        rear = 0;
    }
    //Пред.: нет; Пост.: ArrayQueueModule obj:
    public static ArrayQueueModule getObj() {
        if (obj == null) obj = new ArrayQueueModule();
        return obj;
    }
}

