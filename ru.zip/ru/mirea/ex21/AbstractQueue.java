package ru.mirea.ex21;

public class AbstractQueue {
    protected int rear,front;
}

