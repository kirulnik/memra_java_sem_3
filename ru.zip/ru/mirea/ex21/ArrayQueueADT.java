package ru.mirea.ex21;


public class ArrayQueueADT {
    // Инвариант класса: SIZE >= 0
    public ArrayQueueADT(ArrayQueueModule queue) {
        this.queue = queue;
    }
    private ArrayQueueModule queue;
    public void enqueue(Object v) {
        queue.enqueue(v);
    };
    public Object dequeue() {
        return queue.dequeue();
    };
    public Object element() {
        return queue.element();
    };
    public boolean isEmpty() {
        return queue.isEmpty();
    };
    public void clear() {
        queue.clear();
    };
    public int size() {
        return queue.size();
    }
}
