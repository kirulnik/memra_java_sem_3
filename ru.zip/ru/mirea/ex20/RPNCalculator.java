package ru.mirea.ex20;

import java.util.Scanner;
import java.util.Stack;
public class RPNCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите выражение в польской нотации: ");
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");
        Stack<Double> stack = new Stack<>();
        for (String token : tokens) {
            if (token.equals("+")) {
                double b = stack.pop();
                double a = stack.pop();
                stack.push(a + b);
            } else if (token.equals("-")) {
                double b = stack.pop();
                double a = stack.pop();
                stack.push(a - b);
            } else if (token.equals("*")) {
                double b = stack.pop();
                double a = stack.pop();
                stack.push(a * b);
            } else if (token.equals("/")) {
                double b = stack.pop();
                double a = stack.pop();
                stack.push(a / b);
            } else {
                stack.push(Double.parseDouble(token));
            }
        }
        System.out.println("Result: " + stack.pop());
    }
}
