package ru.mirea.ex4_5_.Shape;

public interface Movable {
    public void moveUp();
    public void moveDown();
    public void moveLeft();
    public void moveRight();
}
class MovablePoint implements Movable {
    int x;
    int y;
    int xSpeed;
    int ySpeed;
    public MovablePoint(int x, int y, int xSpeed, int ySpeed){
        this.x = x;
        this.y = y;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }

    MovablePoint() {}

    public String toString(){
        return "x = "+this.x+"\n" + "y = "+this.y+ "\n" + "xSpeed = "+this.xSpeed+ "\n"+"ySpeed = "+this.ySpeed+"\n";
    }
    @Override
    public void moveUp(){
        y += ySpeed;
    }
    @Override
    public void moveDown(){
        y -= ySpeed;
    }
    @Override
    public void moveLeft(){
        x -= xSpeed;
    }
    @Override
    public void moveRight(){
        x += xSpeed;
    }
}
class MovableCircle extends MovablePoint{
    protected int radius;
    protected MovablePoint center;


    MovableCircle(int x, int y, int xSpeed, int ySpeed, int radius){
        this.x = x;
        this.y = y;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.radius = radius;
    }
    public String toString(){
        return "x = "+this.x+"\n" + "y = "+this.y+ "\n" + "xSpeed = "+this.xSpeed+ "\n"+"ySpeed = "+this.ySpeed+"\n" + "radius = "+this.radius+ "\n";
    }
    @Override
    public void moveUp(){
        y += ySpeed;
    }
    @Override
    public void moveDown(){
        y -= ySpeed;
    }
    @Override
    public void moveLeft(){
        x -= xSpeed;
    }
    @Override
    public void moveRight(){
        x += xSpeed;
    }
}
class MovableRectangle extends MovablePoint{
    protected MovablePoint topLeft;
    protected MovablePoint bottomRight;
    int x2;
    int y2;
    public MovableRectangle(int x, int y, int x2, int y2, int xSpeed, int ySpeed){
        this.x = x;
        this.y = y;
        this.x2 = x2;
        this.y2 = y2;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }
    public String toString(){
        return "x = "+this.x+"\n"+"x2 = "+this.x2+"\n" + "y = "+this.y+ "\n"+"y2 = "+this.y2+"\n" + "xSpeed = "+this.xSpeed+ "\n"+"ySpeed = "+this.ySpeed+"\n";
    }
    @Override
    public void moveUp(){
        y += ySpeed;
    }
    @Override
    public void moveDown(){
        y -= ySpeed;
    }
    @Override
    public void moveLeft(){
        x -= xSpeed;
    }
    @Override
    public void moveRight(){
        x += xSpeed;
    }
    public boolean checkSameSpeed() {
        return xSpeed == ySpeed;
    }
}
