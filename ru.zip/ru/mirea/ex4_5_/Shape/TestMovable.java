package ru.mirea.ex4_5_.Shape;

public class TestMovable {
    public static void main(String[] args) {
        System.out.println("Точка:"+"\n");
        MovablePoint s1 = new MovablePoint(15, 16, 20, 12);
        s1.moveDown();
        System.out.println(s1.toString());
        System.out.println("Круг:"+"\n");
        MovableCircle s2 = new MovableCircle(2,6, 1, 3, 7);
        s2.moveDown();
        System.out.println(s2.toString());
        System.out.println("Прямоугольник:"+"\n");
        MovableRectangle s3 = new MovableRectangle(10, 20, 60,70,3,6);
        if (!s3.checkSameSpeed()) {
            System.out.println("Значения xSpeed и ySpeed не равны!");
            return;
        }
        s3.moveDown();
        System.out.println(s3.toString());
    }
}
