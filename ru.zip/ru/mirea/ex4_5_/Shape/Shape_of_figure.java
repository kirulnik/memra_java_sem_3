package ru.mirea.ex4_5_.Shape;

abstract class Shape {
    protected String color;
    protected boolean filled;
    public Shape(){}
    public Shape(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color= color;
    }
    public boolean isFilled() {
        return filled;
    }
    public void setFilled(boolean filled) {
        this.filled = filled;
    }
    public abstract double getArea();
    public abstract double getPerimetr();
    public abstract String toString();
}

// Дочерний класс Circle (круг)
class Circle extends Shape {
    protected double radius;
    public Circle() {
        this.filled = false;
        this.color = "blue";
        this.radius = 1;
    }
    public Circle(double radius) {
        this.filled = false;
        this.color = "blue";
        this.radius = radius;
    }
    public Circle(double radius, String color, boolean filled) {
        this.radius = radius;
        this.color = color;
        this.filled = filled;
    }
    public double getRadius(){
        return radius;
    }
    public void setRadius(double radius){
        this.radius=radius;
    }
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
    @Override
    public double getPerimetr() {
        return Math.PI * 2 * radius;
    }
    @Override
    public String toString() {
        return "Shape: circle, radius: "+this.radius+", color:"+this.color;
    }
}

// Дочерний класс Rectangle (прямоугольник)
class Rectangle extends Shape {
    protected double width;
    protected double length;

    public Rectangle() {
        this.filled = false;
        this.color = "blue";
        width = 15;
        length = 20;
    }

    public Rectangle(double width, double length) {
        this.filled = false;
        this.color = "blue";
        this.width = width;
        this.length = length;
    }

    public Rectangle(double width, double length, String color, boolean filled) {
        this.filled = filled;
        this.color = color;
        this.width = width;
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    @Override
    public double getArea() {
        return width * length;
    }

    @Override
    public double getPerimetr() {
        return (width + length) * 2;
    }

    @Override
    public String toString() {
        return "Shape: circle, width: " + this.width + ", length:" + this.length + ", color:" + this.color;

    }
}
// Дочерний класс Square (треугольник)
class Square extends Rectangle {
    public double getSide() {
        return this.width;
    }
    public Square() {
        this.filled = false;
        this.color = "blue";
        this.width = 15;
    }

    public Square(double width) {
        this.filled = false;
        this.color = "blue";
        this.width = width;
    }

    public Square(double width, String color, boolean filled) {
        this.filled = filled;
        this.color = color;
        this.width = width;
    }


    @Override
    public double getArea() {
        return width * width;
    }

    @Override
    public double getPerimetr() {
        return width * 4;
    }

    @Override
    public String toString() {
        return "Shape: circle, width: " + this.width + ", color:" + this.color;
    }
}


// Пример использования классов
public class Shape_of_figure {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println("Площадь круга: "+ circle.getArea());
        System.out.println("Периметр круга: "+ circle.getPerimetr());
        System.out.println(circle.toString());

        Rectangle rectangle = new Rectangle(15, 20);
        System.out.println("Площадь прямоугольника: "+ rectangle.getArea());
        System.out.println("Периметр прямоугольника: "+ rectangle.getPerimetr());
        System.out.println(rectangle.toString());

        Square square = new Square(25);
        System.out.println("Площадь квадрата: "+ square.getArea());
        System.out.println("Периметр квадрата: "+ square.getPerimetr());
        System.out.println(square.toString());
    }
}
